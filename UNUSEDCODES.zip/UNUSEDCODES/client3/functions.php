<?php
/**
 * Theme functions and definitions
 *
 * @package HelloElementorChild
 */

/**
 * Load child theme css and optional scripts
 *
 * @return void
 */
function hello_elementor_child_enqueue_scripts() {
	wp_enqueue_style(
		'hello-elementor-child-style',
		get_stylesheet_directory_uri() . '/style.css',
		[
			'hello-elementor-theme-style',
		],
		'1.0.0'
	);
}
add_action( 'wp_enqueue_scripts', 'hello_elementor_child_enqueue_scripts', 20 );

// if (!is_admin()) {
//     function wpb_search_filter($query) {
//         if ($query->is_search) {
//             $query->set('post_type', 'resource');
//         }
//         return $query;
//     }
//     add_filter('pre_get_posts','wpb_search_filter');
// }


add_shortcode( 'ourauthors', 'authors' );
function authors( $atts ) { 
ob_start();?> 
<?php
$author = get_field('authors');
if( $author ): ?>
    <?php foreach( $author as $autho ): 
        $title = get_the_title( $autho->ID );
        $custom_field = get_field( 'field_name', $autho->ID );
        ?>
            <span><?php echo esc_html( $title ); ?></span><br>
    <?php endforeach; ?>
<?php endif; ?>
<?php      
$authors = ob_get_clean();
return $authors;
    
}

// the ajax function
add_action('wp_ajax_myfilter', 'misha_filter_function');
add_action('wp_ajax_nopriv_myfilter', 'misha_filter_function');
function misha_filter_function(){
	//echo '<pre>';print_r($_POST);
    
    if(empty( $_POST['categoryfilter'][0]) && !empty( $_POST['keyword'])){
	
      $addarr = array(
            'post_type' => 'resource',
            'status' => 'publish',
            'posts_per_page' => -1,           
            'meta_key'          => 'publication_date',
            'orderby'           => 'meta_value',
            'order'             => 'DESC',
            's' => $_POST['keyword']
        );  
    }
    if(!empty( $_POST['categoryfilter'][0]) && empty( $_POST['keyword'])){

        $addarr = array(
                'post_type' => 'resource',
                'status' => 'publish',
                'posts_per_page' => -1,                           
                'meta_key'          => 'publication_date',
                'orderby'           => 'meta_value',
                'order'             => 'DESC',
                'tax_query' => array(
                    array(
                        'taxonomy' => 'industries',
                        'field' => 'id',
                        'terms' => $_POST['categoryfilter']
                    )
                )
            );
    }  
	if(!empty( $_POST['categoryfilter'][0]) && !empty( $_POST['keyword'])){

        $addarr = array(
                'post_type' => 'resource',
                'status' => 'publish',           
                'meta_key'          => 'publication_date',
                'orderby'           => 'meta_value',
                'order'             => 'DESC',
                'posts_per_page' => -1,
				's' => $_POST['keyword'],
                'tax_query' => array(
                    array(
                        'taxonomy' => 'industries',
                        'field' => 'id',
                        'terms' => $_POST['categoryfilter']
                    )
                )
            );
    } 
     if(empty( $_POST['categoryfilter'][0]) && empty( $_POST['keyword'])){

	    $addarr = array(
	     'post_type' => 'resource',
	     'status' => 'publish',
     	 'posts_per_page' => -1,           
        'meta_key'          => 'publication_date',
        'orderby'           => 'meta_value',
        'order'             => 'DESC'
	    
	  );
	 }
    /*issue aaaye to niche wali line ko comment karke dekha lena*/
   //echo '<pre>';print_r($addarr);

    $query = new WP_Query( $addarr );	
	$retdata='';
    if( $query->have_posts() ) :
        while( $query->have_posts() ): $query->the_post();  
        $terms = get_the_terms( get_the_ID(), 'industries' ); 
        $terms = join(', ', wp_list_pluck( $terms , 'name') ); 
        $file = get_field('resource_upload');
        $description = get_field('description'); 
        $publication_date = get_field('publication_date');  
        $fileurl = $file['url'];
        $retdata.='<div class="inner-resource"><div class="resource-item">
            <div class="col-6">
                 <h3>'.get_the_title().' </h3>       
                <p><b>Date:</b>'.$publication_date .'</p>
                <p>'.$description.'</p>
                 <div class="mobile"><p> <b>Authors:</b> '.do_shortcode("[ourauthors]").' </p></div>
                 <div class="mobile"><p><b>Industries:</b> '.$terms.'</p></div>
                <a href="'.$fileurl.'" class="elementor-button elementor-button-link elementor-size-md" target="_blank"><span class="elementor-button-content-wrapper"><span class="elementor-button-text" >Download</span></span></a>
            </div>
            <div class="col-2 desktop"><p>'.do_shortcode("[ourauthors]").'</p>
            </div>
            <div class="col-2 desktop"><p>'.$terms.'</p></div>
        </div></div>';
         endwhile;
		
        wp_reset_postdata();  
    endif;
	
	echo $retdata;
    die();
}

add_shortcode( 'ourresource', 'resource' );
function resource( $atts ) { 
ob_start();
?> 

<style>
form#filter {
    display: flex;
    margin-bottom: 20px;
}
.resource-topbar p {
    margin: 0;
     font-size: 12px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.33;
  letter-spacing: normal;
  color: #202020;
}
.resource-topbar .col-6, .resource-item .col-6 {
    width: 70%;
    padding-right: 30px;
}
.resource-topbar .col-2, .resource-item .col-2 {
    width: 15%;
    text-align: left;
}
.resource-topbar{
    display: flex;
   margin-bottom: 29px;
   margin-top: 40px;
}
.resource-item {
    display: flex;
   margin-bottom: 35px;
}
.resource-item h3 {
    font-family: "Inter", Sans-serif;
    font-size: 20px;
    font-weight: bold;
    font-stretch: normal;
    font-style: normal;
    line-height: 1.2;
    letter-spacing: normal;
    color: #081729;
        margin-top: 0;
    margin-bottom: 15px;
}
.resource-item p{
  font-size: 14px;
  font-weight: normal;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.43;
  letter-spacing: normal;
  color: #202020;
}
select{
    background-color: #e4e3e2;
    padding: 12px 15px !important;
    border: unset;
    border-radius: unset;
    margin-right: 5px;
        height: 50px;
        outline: none;
        width: 40%;
}
input.input_search {
    background-color: #e4e3e2;
    padding: 12px 15px !important;
    border: unset;
    border-radius: unset;
    margin-right: 5px;
    outline: none;
    height: 50px;
    width: 40%;
}
.search_bar button:hover, button {
    background: #081729 !important;
    font-size: 16px;
    font-weight: bold;
    font-stretch: normal;
    font-style: normal;
    line-height: 1.38;
    letter-spacing: normal;
    text-align: center;
    color: #f2f0ee !important;
}
.resource-item .elementor-button {
    margin-top: 20px;
    padding: 6px 25px 6px 25px;
    border-radius: 18px;
    background: transparent !important;
    font-size: 16px;
    font-weight: bold;
    font-stretch: normal;
    font-style: normal;
    !important;
    font-size: 16px;
    font-weight: bold;
    font-stretch: normal;
    font-style: normal;
    line-height: 1.38;
    letter-spacing: normal;
    text-align: center;
    color: #081729 !important;
}
button {
    width: 20% !important;
    height: 50px;
     border-radius: 20px;
}
.resource-listing .listing-inner-resource{ display:none;
}
#loadMore {
    color: #fff;
    cursor: pointer;
    border-style: solid;
    border-width: 2px 2px 2px 2px;
    border-color: #081729;
    border-radius: 30px 30px 30px 30px;
    width: 15%;
    text-align: center;
    background: #081729;
    padding: 7px;
    font-weight: 600;
}
 .mobile {
    display:none;
  }
 @media screen and (max-width: 767px) {
#loadMore {
    width: 25%;
}
} 
@media screen and (max-width: 600px) {
  .desktop {
    display:none;
  }
  .mobile {
    display:block;
  }
  .resource-item .col-6 {
    width: 100%;
    padding-right: 0px;
}
}
 @media screen and (max-width:500px) {
input.input_search, select {
    margin-right: 0px;
    margin-bottom: 8px;
    width: 100%;
}
form#filter {
 flex-wrap: wrap;
}
button {
    width: 40% !important;
}
#loadMore {
    width: 45%;
}
}
</style>

<div class="search_bar">
    <form action="" method="POST" id="filter" >
      <input type="text" placeholder="Search..." name="keyword" value="" class="input_search"  />
        <select name="categoryfilter[]">
              <option value="">Select an industry</option>
              <?php 
              $cattype = get_terms( array(
              'taxonomy'      => 'industries',
              'hide_empty'    => false,
                  ) );  
                  foreach ($cattype as $cattyp) {
              ?>
              <option value="<?php echo $cattyp->term_id; ?>"  ><?php echo $cattyp->name ?></option>
              <?php
                    }
                ?> 
        </select>
       <button type="submit" form="filter" alue="Submit">Submit</button>
       <input type="hidden" name="action" value="myfilter">
    </form>    
</div>
<div class="resource-topbar desktop">
<div class="col-6"><p>Title</p></div>
<div class="col-2"><p>Authors</p></div>
<div class="col-2"><p>Industries</p></div>
</div>
<div class="resource-listing listing2" id="response">
    <?php 
    $today = date('Ymd');
        $the_query = new WP_Query( 
            array( 
                'posts_per_page' => -1, 
                'status' => 'publish',  
                'post_type' => 'resource',
                'meta_key'          => 'publication_date',
                'orderby'           => 'meta_value',
                'order'             => 'DESC'
     ) );  
        if( $the_query->have_posts() ) :
        while( $the_query->have_posts() ): $the_query->the_post();
        $terms = get_the_terms( get_the_ID(), 'industries' ); 
        $terms = join(', ', wp_list_pluck( $terms , 'name') ); 
        $file = get_field('resource_upload');
         $description = get_field('description');
         $publication_date = get_field('publication_date');   
         ?>
        <div class="inner-resource listing-inner-resource">
        <div class="resource-item">
            <div class="col-6">                
                <h3><?php the_title();?> </h3>
                <p><b>Date:</b> <?php echo $publication_date; ?></p>
                <p><?php echo $description;?></p>
                <!--<p><?php echo get_the_excerpt();?></p>-->
                <div class="mobile"><p><b>Authors:</b> 
                <?php
                $author = get_field('authors');
                if( $author ): ?>
                    <?php foreach( $author as $autho ): 
                        $title = get_the_title( $autho->ID );
                        $custom_field = get_field( 'field_name', $autho->ID );
                        ?>
                            <span><?php echo esc_html( $title ); ?></span> 
                    <?php endforeach; ?>
                <?php endif; ?></p>
                </div>
                <div class="mobile"><p><b>Industries:</b> <?php  echo $terms; ?></p></div>
                <a href="<?php echo $file['url']; ?>" class="elementor-button elementor-button-link elementor-size-md" target="_blank"><span class="elementor-button-content-wrapper">
				<span class="elementor-button-text" >Download</span></span></a>
            </div>
            <div class="col-2 desktop">
            <p>
                <?php
                $author = get_field('authors');
                if( $author ): ?>
                    <?php foreach( $author as $autho ): 
                        $title = get_the_title( $autho->ID );
                        $custom_field = get_field( 'field_name', $autho->ID );
                        ?>
                           <span><?php echo esc_html( $title ); ?></span><br>
                    <?php endforeach; ?>
                <?php endif; ?>
               </p> 
            </div>
            <div class="col-2 desktop"><p><?php  echo $terms; ?></p></div>
        </div>
          </div>
        <?php endwhile;
        endif;
     ?>
     <div id="loadMore">Load more</div>
</div>

<script type="text/javascript">
 jQuery( document ).ready(function() {     
  jQuery(function($){
        $('#filter').submit(function(){
            var filter = $('#filter');
            $.ajax({
                url:"<?php echo admin_url('admin-ajax.php'); ?>",
                data:filter.serialize(), 
                type:filter.attr('method'),
                beforeSend:function(xhr){
                    filter.find('button').text('Processing...'); 
                },
                success:function(data){
                    filter.find('button').text('Submit'); 
                    $('#response').html(data); 
                }
            });
            return false;
        });

    });
    size_li = jQuery(".resource-listing .inner-resource").size();
    x=9;
    jQuery('.resource-listing .inner-resource:lt('+x+')').show();
    jQuery('#loadMore').click(function () {
        x= (x+9 <= size_li) ? x+9 : size_li;
        jQuery('.resource-listing .inner-resource:lt('+x+')').show();
        if(x == size_li){
            $('#loadMore').hide();
        }
    });
    jQuery('#showLess').click(function () {
        x=(x-9<0) ? 9 : x-9;
        jQuery('.resource-listing .inner-resource').not(':lt('+x+')').hide();
    });    
});
</script>
 <?php  
$resource = ob_get_clean();
return $resource;    
}

add_filter('pto/posts_orderby/ignore', 'theme_pto_posts_orderby', 10, 3);

function theme_pto_posts_orderby($ignore, $orderBy, $query)

   {

       if( (! is_array($query->query_vars['post_type']) && $query->query_vars['post_type'] == 'resource') ||

               (is_array($query->query_vars)   &&  in_array('resource', $query->query_vars)))

               $ignore = TRUE;

       return $ignore;

   }


add_shortcode( 'keycontacts', 'keycontact' );
function keycontact( $atts ) { 
ob_start(); 
$key_contacts = get_field('key_contacts');
//echo '<pre>';print_r($teams);
if( $key_contacts ): ?>
<style>
.keycontacts {
    display: flex;
    flex-wrap: wrap;
}
.keycontact-col {
    padding: 20px;
    width: 33.33%;
}
.keycontact-img img {
    border-radius: 10px;
}
.keycontact-img img:hover {
    opacity: 0.6;
}
.keycontact-img {
    position: relative;
}
.keycontact-content {
    margin: 28px 0;
}
.keycontact-img .elementor-icon {
    position: absolute;
    left: 25px;
    bottom: 20px;
    transform: rotate(-45deg);
    color: #FFFFFF;
    border-color: #FFFFFF;
    font-size:30px;
}
.keycontact-content h5.elementor-heading-title {
    font-size: 16px;
    font-weight: 700;
    line-height: 24px;
}
.keycontact-content li.elementor-icon-list-item {
    font-size: 14px;
    font-weight: 400;
    line-height: 20px;
}
span.boder {
    background: #000;
    height: 10px;
    width: 68px;
    display: block;
    margin-top: 30px;
}
@media screen and (max-width: 767px) {
 .keycontact-col {
    width: 50%;
    padding: 12px;
}
}
@media screen and (max-width: 600px) {
 .keycontact-col {
    width: 100%;
}
}
</style>
<div class="keycontacts ">
	<?php     
    foreach( $key_contacts as $team ): 
	$full_name = get_field('full_name', $team->ID);	
	$job_title = get_field('job_title', $team->ID);	
	$email_address = get_field('email_address', $team->ID);	
	$terms = get_the_terms( $team->ID, 'city' );
    $terms = join(', ', wp_list_pluck( $terms , 'name') );
    $featured_img_url = get_the_post_thumbnail_url($team->ID); 
   // print_r($team);
	?>
	<div class="keycontact-col">
		<a class="keycontact-img"  href="<?php echo get_permalink( $team->ID ); ?>">
			<img src="<?php echo $featured_img_url; ?>">
			<p class="elementor-icon">
			<i aria-hidden="true" class="hm hm-arrow-right"></i></p>
		</a>
		<div class="keycontact-content">
			<h5 class="elementor-heading-title elementor-size-default"><?php echo $full_name; ?></h5>
			<ul class="elementor-icon-list-items elementor-post-info">
				<li class="elementor-icon-list-item">
					<span class="elementor-icon-list-text"><?php echo $job_title; ?></span>
				</li>
				<li class="elementor-icon-list-item">
					<span class="elementor-icon-list-text"><?php echo $terms; ?></span>
				</li>
				<li class="elementor-icon-list-item">
					<a href="mailto:<?php echo $email_address; ?>" rel="nofollow">
						<span class="elementor-icon-list-text"><?php echo $email_address; ?></span>
					</a>
				</li>
			</ul>
            <span class="boder"></span>
		</div>
	</div>
	<?php endforeach; ?>	
</div>
<?php endif; 
$keycontact = ob_get_clean();
return $keycontact;
    
}

add_shortcode( 'expertise_keycontacts', 'exp_keycontact' );
function exp_keycontact( $atts ) { 
ob_start(); 
$key_contacts = get_field('key_contacts');
//echo '<pre>';print_r($teams);
if( $key_contacts ): ?>
<style>
.keycontacts {
    display: flex;
    flex-wrap: wrap;
}
.keycontact-col {
    padding: 20px;
    width: 33.33%;
}
.keycontact-img img {
    border-radius: 10px;
}
.keycontact-img img:hover {
    opacity: 0.6;
}
.keycontact-img {
    position: relative;
}
.keycontact-content {
    margin: 28px 0;
}
.keycontact-img .elementor-icon {
    position: absolute;
    left: 25px;
    bottom: 20px;
    transform: rotate(-45deg);
    color: #FFFFFF;
    border-color: #FFFFFF;
    font-size:30px;
}
.keycontact-content h5.elementor-heading-title {
    font-size: 16px;
    font-weight: 700;
    line-height: 24px;
}
.keycontact-content li.elementor-icon-list-item {
    font-size: 14px;
    font-weight: 400;
    line-height: 20px;
}
span.boder {
    background: #000;
    height: 10px;
    width: 68px;
    display: block;
    margin-top: 30px;
}
@media screen and (max-width: 767px) {
 .keycontact-col {
    width: 50%;
    padding: 12px;
}
}
@media screen and (max-width: 600px) {
 .keycontact-col {
    width: 100%;
}
}
</style>
<div class="keycontacts ">
	<?php     
    foreach( $key_contacts as $team ): 
	$full_name = get_field('full_name', $team->ID);	
	$job_title = get_field('job_title', $team->ID);	
	$email_address = get_field('email_address', $team->ID);	
	$terms = get_the_terms( $team->ID, 'city' );
    $terms = join(', ', wp_list_pluck( $terms , 'name') );
    $featured_img_url = get_the_post_thumbnail_url($team->ID); 
   // print_r($team);
	?>
	<div class="keycontact-col">
		<a class="keycontact-img"  href="<?php echo get_permalink( $team->ID ); ?>">
			<img src="<?php echo $featured_img_url; ?>">
			<p class="elementor-icon">
			<i aria-hidden="true" class="hm hm-arrow-right"></i></p>
		</a>
		<div class="keycontact-content">
			<h5 class="elementor-heading-title elementor-size-default"><?php echo $full_name; ?></h5>
			<ul class="elementor-icon-list-items elementor-post-info">
				<li class="elementor-icon-list-item">
					<span class="elementor-icon-list-text"><?php echo $job_title; ?></span>
				</li>
				<li class="elementor-icon-list-item">
					<span class="elementor-icon-list-text"><?php echo $terms; ?></span>
				</li>
				<li class="elementor-icon-list-item">
					<a href="mailto:<?php echo $email_address; ?>" rel="nofollow">
						<span class="elementor-icon-list-text"><?php echo $email_address; ?></span>
					</a>
				</li>
			</ul>
            <span class="boder"></span>
		</div>
	</div>
	<?php endforeach; ?>	
</div>
<?php endif; 
$exp_keycontact = ob_get_clean();
return $exp_keycontact;
    
}
/*22 Jan 2024 Code by Issac*/
function filter_enqueue_scripts(){

 
     wp_enqueue_style('bs502','https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css');
     wp_enqueue_script('bs502','https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js',array('jquery'));

    wp_enqueue_style('customfilter', get_template_directory_uri() . '/css/style.css', array(), '1.0', 'all');

    wp_enqueue_script('customfilter', get_template_directory_uri(). '/js/filter.js', array('jquery'),rand(),true);

    wp_localize_script( 'customfilter', 'themeData', array(

        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'templatedirectory' => get_template_directory_uri(),

    ));

}
add_action( 'wp_enqueue_scripts', 'filter_enqueue_scripts' );


function filter_product_callback(){

/*Array
(
    [action] => filter_product
    [category] => 15,13,
    [brand] => 21,23,12,
    [pageno] => 1
)
*/

    $category    = sanitize_text_field(trim($_POST['category'])) ;
    $brand       = sanitize_text_field(trim($_POST['brand']) );
    $paged       = sanitize_text_field($_POST['pageno']);
    $searchtext  = sanitize_text_field($_POST['searchtext']);


    if (!empty($category)) {
        $category    = explode(',', $category);
    }
    if (!empty($brand)) {
        $brand       = explode(',', $brand);
    }



    $tax_query = array();

    if($brand){
        $tax_query[] = array(
            'taxonomy' => 'product-brand',
            'field'     => 'term_id',
            'terms'     => $brand,
        );
    }
    if($category){
        $tax_query[] = array(
            'taxonomy'  => 'product-category',
            'terms'     => $category,
            'field'     => 'term_id',
        );

    }


    if(!empty($tax_query)){
        $tax_query['relation'] = 'AND';
        $args = array(
            'post_type'      => 'products',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'tax_query'      => $tax_query,
            's'              => $searchtext
        );
    } else {
        $args = array(
            'post_type'      => 'products',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            's'              => $searchtext
        );

        if(empty($searchtext)){
            unset($args['s']);
        }
    }


    $loop = new WP_Query($args);

    if($loop->have_posts()){
        while($loop->have_posts()){
            $loop->the_post();
            $thumbnail = wp_get_attachment_image_src(get_post_thumbnail_id(), 'medium');
    ?>
    <div class="col-sm-12 col-md-6 col-lg-4 center-cards">
        <div class=" card-width ">
            <img src="<?php echo $thumbnail[0]; ?>" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title"><?php the_title(); ?></h5>
                <p class="card-text"><?php the_title(); ?></p>
                <a href="<?php the_permalink(); ?>" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
    </div>
    <?php
        }
    }


    die; 
}
add_action('wp_ajax_filter_product', 'filter_product_callback');
add_action('wp_ajax_nopriv_filter_product', 'filter_product_callback');



function filter_product_shortcode(){

    $brands = get_terms(array(
        'taxonomy' => 'product-brand', 
        'hide_empty' => false,

    ));
    $brandslist = '';

    $categorys = get_terms(array(
        'taxonomy' => 'product-category', 
        'hide_empty' => false,

    ));
    $categorylist = '';

    $i = 1; 
    foreach ($brands as $brand) {
    $brandslist .=  
    '<li>
        <input class="form-check-input tax1" type="checkbox" value="'.$brand->term_id.'" id="option'.$i.'">
        <label class="form-check-label" for="option'.$i.'">'.$brand->name.'</label>
      </li>';

    $i++; 
    }


    $j = 1; 
    foreach ($categorys as $category) {
    $categorylist .=  
    '<li>
        <input class="form-check-input tax2" type="checkbox" value="'.$category->term_id.'" id="option'.$j.'">
        <label class="form-check-label" for="option'.$i.'">'.$category->name.'</label>
      </li>';

    $j++; 
    }


    $var = '    <div class="container  mx-auto  content">
        <div class="row my-4">
           <div class="col-sm-12 col-md-6 col-lg-4">
           <input class="form-control w-100 py-2 mb-4 custom-search-input" placeholder="Search" id="searchtext" />

           </div>

           <!-- DROPDOWN1 -->
           <div class="col-sm-12 col-md-6 col-lg-4">
            <div class="dropdown mb-4">
                <button class="btn btn-custom dropdown-toggle w-100" type="button" id="multiSelectDropdown1" data-bs-toggle="dropdown" aria-expanded="false">
                  Select Options
                </button>
                <ul class="dropdown-menu px-2 w-100" aria-labelledby="multiSelectDropdown1" id="multiSelectDropdown1">'.$brandslist.'
                  <!-- Add more options as needed -->
                </ul>
              </div>
           </div>


            <!-- DROPDOWN 2 -->
           <div class="col-sm-12 col-md-6 col-lg-4">
            <div class="dropdown mb-4">
                <button class="btn btn-custom dropdown-toggle w-100" type="button" id="multiSelectDropdown2" data-bs-toggle="dropdown" aria-expanded="false">
                  Select Options
                </button>
                <ul class="dropdown-menu px-2 w-100" aria-labelledby="multiSelectDropdown2" id="multiSelectDropdown2">'.$categorylist.'
                    <!-- Add more options as needed -->
                </ul>
              </div>
           </div>
          <!-- TEST DROP -->
         
        </div>

        <!-- CARD SECTION -->
        <div class="row " id="products">

        </div>
    </div>'; 

    return $var; 

}

add_shortcode('filter_product', 'filter_product_shortcode');
/*22 Jan 2024 End of Code by Issac*/