<?php 
/**
 * Vicinity Energy functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Vicinity_Energy
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function vicinityenergy_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on Vicinity Energy, use a find and replace
		* to change 'vicinityenergy' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'vicinityenergy', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__( 'Primary', 'vicinityenergy' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'vicinityenergy_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'vicinityenergy_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function vicinityenergy_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'vicinityenergy_content_width', 640 );
}
add_action( 'after_setup_theme', 'vicinityenergy_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function vicinityenergy_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'vicinityenergy' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'vicinityenergy' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'vicinityenergy_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function vicinityenergy_scripts() {
	wp_enqueue_style( 'vicinityenergy-style', get_stylesheet_uri(), array(), _S_VERSION );
	wp_style_add_data( 'vicinityenergy-style', 'rtl', 'replace' );


	wp_enqueue_script('customfilter', get_template_directory_uri(). '/filter.js', array('jquery'),rand(),true);

    wp_localize_script( 'customfilter', 'themeData', array(

        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'templatedirectory' => get_template_directory_uri(),

    ));

	wp_enqueue_script( 'vicinityenergy-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'vicinityenergy_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}


// Author bio + social media
function author_bio_social() {
	$post_author = get_the_author();
	$author_bio = get_the_author_meta('description');
	$twitter = get_the_author_meta('twitter');
	$linkedin = get_the_author_meta('linkedin');
	$instagram = get_the_author_meta('instagram');
	$facebook = get_the_author_meta('facebook');
	$email= get_the_author_meta('email');
	
	ob_start();
	echo '<div><p>' . $author_bio . '</p></div>';
	echo '<div class="author-social-media"><ul class="et_social_icons_container">';
	if (!empty($twitter)) {
		echo '<li class="et-social-twitter"><a href="https://twitter.com/' . $twitter . '" class="et_social_share" target="_blank"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>';
	}
	if (!empty($instagram)) {
		echo '<li class="et-social-instagram"><a href="' . $instagram . '" class="et_social_share" target="_blank"<i class="fab fa-instagram" aria-hidden="true"></i></a></li>';
	}
	if (!empty($facebook)) {
		echo '<li class="et-social-facebook"><a href="' . $facebook . '" class="et_social_share" target="_blank"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>';
	}
	if (!empty($linkedin)) {
		echo '<li class="et-social-linkedin"><a href="' . $linkedin . '" class="et_social_share" target="_blank"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>';
	}
	if (!empty($email)) {
// 		echo '<li class="et-social-email"><a href=mailto:"' . $email . '" class="et_social_share" target="_blank"><i class="et_social_icon et_social_icon_email"></i></a></li>';
	}
	echo '</ul></div>';
	$html = ob_get_contents();
	$output = ob_get_clean();
	return $output;
}
add_shortcode('author-bio-social', 'author_bio_social');


function filter_enqueue_scripts(){
    wp_enqueue_style('customfilter', get_template_directory_uri() . '/fliter-style.css', array(), '1.0', 'all');
    wp_enqueue_script('customfilter', get_template_directory_uri(). '/filter.js', array('jquery'),rand(),true);
    wp_localize_script( 'customfilter', 'themeData', array(
        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'templatedirectory' => get_template_directory_uri(),
    ));
}
add_action( 'wp_enqueue_scripts', 'filter_enqueue_scripts' );



add_shortcode( 'ourresource', 'resource' );
function resource( $atts, $content = null) { 
$atts = shortcode_atts( array(
        'category' => false,
    ), $atts );
ob_start();
?> 
<div class="customfilter"  id="resources">
<div class="filter-form">
		<div class="filter-row">
			<div class="filter-col-3">
				<select name="" id="category" onchange="javascript:location.href = this.value;">
					<option data-tid="21" value="<?php echo get_site_url();?>/resources/ourbrochures/">Brochures</option>
					<option data-tid="162" value="<?php echo get_site_url();?>/customers/our-customer-stories/">CUSTOMER STORIES</option>
					<option data-tid="148" value="<?php echo get_site_url();?>/resources/ournewsroom/">Newsroom</option>
					<option data-tid="70" value="<?php echo get_site_url();?>/resources/ourpodcasts/">Podcasts</option>
					<option data-tid="19" value="<?php echo get_site_url();?>/resources/our-press-releases/">Press Releases</option>
					<option data-tid="22" value="<?php echo get_site_url();?>/resources/ourvideos/">videos</option>
					<option data-tid="149" value="<?php echo get_site_url();?>/resources/our-white-papers/">White papers</option>
				</select>
			</div>
			<div class="filter-col-3">
				<select id="SelectDropdown2">
					<option value="">Industry</option>
					<?php 
					$i = 1;
	              $cattype = get_terms( array(
	              'taxonomy'      => 'industry',
	              'hide_empty'    => false,
	                  ) );  
	                  foreach ($cattype as $cattyp) {
	              ?>
					<option value="<?php echo $cattyp->term_id; ?>" id="option<?php echo $i; ?>" ><?php echo $cattyp->name ;?></option>
				<?php $i++;
                    }
                ?>
				</select>
			</div>
			<div class="filter-col-3">
				<select  id="SelectDropdown1">
					<option value="">LOCATIONS</option>
					<?php 
					$j = 1;
	              $cattype = get_terms( array(
	              'taxonomy'      => 'post_tag',
	              'hide_empty'    => false,
	                  ) );  
	                  foreach ($cattype as $cattyp) {
	              ?>
					<option value="<?php echo $cattyp->term_id; ?>" id="option<?php echo $i; ?>"><?php echo $cattyp->name ?></option>
				<?php $j++;
                    }
                ?>
				</select>
			</div>
			<div class="filter-col-12">
				<input class="form-control w-100 py-2 mb-4 custom-search-input" placeholder="Search" id="searchtext" /><i class="fas fa-search"></i>
			</div>
		</div>
</div>
<div class="filter-post-grid-row" id="postsgrid">
	
</div>
	
	<div class="loadmore" style="text-align:center;">
		<div class="elementor-widget-container">
			<div class="elementor-button-wrapper">
				<a href="javascript:void(0);" class="elementor-button elementor-button-link elementor-size-sm" id="loadmore">Load More</a>
				</a>
			</div>
		</div>

        
        <input type="hidden" value="1" id="pageno" />
    </div>

</div>
<style>
	.filter-form {
    max-width: 1040px;
    width: 100%;
    margin: 0 auto;
}

.filter-row .filter-col-3 {
    width: 33.33%;
    padding: 0 20px;
}
.filter-row {
    display: flex;
    flex-wrap: wrap;
}
.filter-col-3 select {
    width: 100%;
    height: 40px;
    padding: 0 10px;
    font-size: 15px;
    line-height: 20px;
    font-weight: 700;
    text-transform: uppercase;
    color: #7E868D;
        background: url(https://vedev1.wpengine.com/wp-content/uploads/2024/02/arrow-drop-down-1.svg) no-repeat right;
    -webkit-appearance: none;
    background-position-x: 260px;
}
.filter-row .filter-col-3:first-of-type select {
    color: #fff;
     background: url(https://vedev1.wpengine.com/wp-content/uploads/2024/02/arrow-drop-down.svg) no-repeat right #009845;
    -webkit-appearance: none;
    background-position-x: 260px;
}
.filter-col-12 {
    width: 100%;
    padding: 50px 20px;
    display: flex;
    align-items: center;
}
.filter-col-12 input {
    width: 100%;
    height: 40px;
    padding: 10px;
    background: #F1F1F1;
    border: 0;
}

.filter-col-12 i {
    margin-left: -47px;
    font-weight: 600;
    color: #7E868D;
}
.filter-post-grid-row {
    display: flex;
    flex-wrap: wrap;
}
.grid-col-3 {
    width: 33.33%;
    padding: 15px;
}
.grid-col-3 img {
    width: 100%;
    height: 240px;
    object-fit: cover;
}
.loadmore a#loadmore {
    background: transparent;
    color: #232629;
    border: 1px solid #232629;
    font-size: 15px;
    font-weight: 700;
    line-height: 20px;
    height: auto !important;
}
.grid-cat {
    width: 100%;
    background: #009845;
    padding: 5px 20px;
}
.grid-cat p {
    margin: 0;
    font-size: 15px;
    color: #fff;
    line-height: 20px;
    font-weight: 700;
    text-transform: uppercase;
}
.grid-content h3 {
    font-size: 24px;
    line-height: 29px;
    color: #232629;
    font-weight: 400;
    margin: 20px 0 0 0;
}
</style>
<script type="text/javascript">
 jQuery( document ).ready(function() {  
 jQuery("option[value='" + window.location.href.toString() + "']").closest("select").val(window.location.href.toString());   
    
});

</script>
 <?php  
$resource = ob_get_clean();
return $resource;    
}


add_action('wp_ajax_filter_product', 'filter_product_callback');
add_action('wp_ajax_nopriv_filter_product', 'filter_product_callback');

function filter_product_callback(){

// (
//     [action] => filter_product
//     [category] => 19
//     [industry] => 133
//     [location] => 41
// )

    $searchtext  = sanitize_text_field($_POST['searchtext']);
	$category    = sanitize_text_field(trim($_POST['category'])) ;
	$industry    = sanitize_text_field(trim($_POST['industry'])) ;
    $location    = sanitize_text_field(trim($_POST['location']) );
    $paged       = sanitize_text_field($_POST['pageno']);


    $tax_query = array();

    if($category){
        $tax_query[] = array(
            'taxonomy'  => 'category',
            'field'     => 'term_id',
            'terms'     => $category,
        );
    }

    if($industry){
        $tax_query[] = array(
            'taxonomy'  => 'industry',
            'field'     => 'term_id',
            'terms'     => $industry,
        );
    }

    if($location){
        $tax_query[] = array(
            'taxonomy'  => 'post_tag',
            'field'     => 'term_id',
            'terms'     => $location,
        );
    }


    $args = array(
        'post_type'      => 'post',
        'post_status'    => 'publish',
        'posts_per_page' => 6,
        'paged'          => $paged,
        'tax_query'      => $tax_query,
        's'              => $searchtext,
    );



	$query = new WP_Query( $args );
	
	if( $query->have_posts() ) : 
		while( $query->have_posts() ): 
			$query->the_post();
			$terms = get_the_terms( get_the_ID(), 'category' ); 
		 	$featured_img_url = get_the_post_thumbnail_url();  
			$terms = join(', ', wp_list_pluck( $terms , 'name') );
		 ?>
		<a class="grid-col-3" href="<?php echo get_permalink(); ?>">
			<div class="grid-cat <?php echo $terms; ?>">
				<p><?php echo $terms; ?></p>
			</div>
			<div class="grid-img"><img src="<?php echo $featured_img_url; ?>"></div>
			<div class="grid-content">
				<h3><?php the_title();?> </h3>				
			</div>
		</a>
	<?php 
		endwhile;
      endif;
  



    die; 
}