jQuery(document).ready(function() {

	var currentURL = window.location.href;
    jQuery('#category option').each(function() {
      var optionValue = jQuery(this).val();
      if (currentURL.indexOf(optionValue) !== -1) {
        jQuery(this).prop('selected', true);
      }
    });


	console.log('ready');
  const ajaxurl = themeData.ajaxurl; 

	jQuery('#SelectDropdown2').change(function(){

		reset();
		var searchtext = jQuery('#searchtext').val();
		var pageno   = jQuery('#pageno').val();
		var category = jQuery("#category option:selected").data("tid");
		var industry = jQuery(this).val();
		var location = jQuery("#SelectDropdown1 option:selected").val();

		var data = { 'action': 'filter_product',searchtext, category, industry, location, pageno };

			jQuery.ajax({
	           	url    : ajaxurl,
	           	type   : 'POST',
	           	data   : data,      
	           	beforeSend: function() {
	                
	            },         
	           	success: function(response) {
	           		jQuery('#postsgrid').empty().append(response);
	           		jQuery('#pageno').val( parseInt(jQuery('#pageno').val()) +1 );
	           	},

          	});

	});


	jQuery('#SelectDropdown1').change(function(){

		reset();
		var searchtext = jQuery('#searchtext').val();
		var pageno   = jQuery('#pageno').val();
		var category = jQuery("#category option:selected").data("tid");
		var industry = jQuery("#SelectDropdown2 option:selected").val();
		var location = jQuery(this).val();

		var data = { 'action': 'filter_product',searchtext, category, industry, location, pageno };

			jQuery.ajax({
	           	url    : ajaxurl,
	           	type   : 'POST',
	           	data   : data,      
	           	beforeSend: function() {
	                
	            },         
	           	success: function(response) {
	           		jQuery('#postsgrid').empty().append(response);
	           		jQuery('#pageno').val( parseInt(jQuery('#pageno').val()) +1 );
	           	},

          	});

	});



	jQuery(document).keydown(function(e) { 
        if (e.which === 13) {

        reset();
		    var searchtext = jQuery('#searchtext').val();
				var pageno   = jQuery('#pageno').val();
				var category = jQuery("#category option:selected").data("tid");
				var industry = jQuery("#SelectDropdown2 option:selected").val();
				var location = jQuery("#SelectDropdown1 option:selected").val();

				var data = { 'action': 'filter_product',searchtext, category, industry, location, pageno };


				jQuery.ajax({
		           	url    : ajaxurl,
		           	type   : 'POST',
		           	data   : data,      
		           	beforeSend: function() {
		                
		            },         
		           	success: function(response) {
		           		jQuery('#postsgrid').empty().append(response);
		           		jQuery('#pageno').val( parseInt(jQuery('#pageno').val()) +1 );
		           	},

	          	});

          }
     });


		jQuery('#loadmore').click(function(){

		    var searchtext = jQuery('#searchtext').val();
				var pageno   = jQuery('#pageno').val();
				var category = jQuery("#category option:selected").data("tid");
				var industry = jQuery("#SelectDropdown2 option:selected").val();
				var location = jQuery("#SelectDropdown1 option:selected").val();

				var data = { 'action': 'filter_product',searchtext, category, industry, location, pageno };

				jQuery.ajax({
           	url    : ajaxurl,
           	type   : 'POST',
           	data   : data,      
           	beforeSend: function() {
                
            },         
           	success: function(response) {
           		if(response.length == 0){
           			jQuery('#loadmore').text('No More Posts');
           		}
           		jQuery('#postsgrid').append(response);
           		jQuery('#pageno').val( parseInt(jQuery('#pageno').val()) +1 );
           	},

        });

		});


	   function reset(){
	   		jQuery('#pageno').val('1');
        jQuery('#loadmore').text('Load More');
	   }


	   /*Document Ready*/

	   		var searchtext = jQuery('#searchtext').val();
				var pageno   = jQuery('#pageno').val();
				var category = jQuery("#category option:selected").data("tid");
				var industry = jQuery("#SelectDropdown2 option:selected").val();
				var location = jQuery("#SelectDropdown1 option:selected").val();

				var data = { 'action': 'filter_product',searchtext, category, industry, location, pageno };

				jQuery.ajax({
           	url    : ajaxurl,
           	type   : 'POST',
           	data   : data,      
           	beforeSend: function() {
                
            },         
           	success: function(response) {
           		if(response.length == 0){
           			jQuery('#loadmore').text('No More Posts');
           		}
           		jQuery('#postsgrid').append(response);
           		jQuery('#pageno').val( parseInt(jQuery('#pageno').val()) +1 );
           	},

        });



})